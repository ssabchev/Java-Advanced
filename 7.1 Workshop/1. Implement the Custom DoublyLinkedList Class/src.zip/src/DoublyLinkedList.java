public class DoublyLinkedList {
    private class Node {
        Node next;
        Node prev;
        int element;

        Node(int element){
            this.next = null;
            this.prev = null;
            this.element = element;
        }

    }

    private Node head;
    private Node tail;
    private int size;


    public DoublyLinkedList() {
       this.head = null;
       this.tail = null;
       this.size = 0;
    }

    public void add(int element) {
        Node newNode = new Node(element);
        if (this.head == null) {
            this.head = this.tail = newNode;
        } else if (size == 1) {
            this.tail.next = newNode;
            this.tail = newNode;
            this.tail.prev = this.head;
        } else {
            this.tail.next = newNode;
            newNode.prev = this.tail;
            this.tail = newNode;
        }
        this.size++;
    }

    public int get(int index) {
        if(index < 0 || index >= this.size) {
            throw new IndexOutOfBoundsException("Invalid Index");
        } else {
            int counter = 0;
            int value = 0;
            Node currentNode = this.head;
            while (currentNode != null) {
                if (counter == index){
                    value = currentNode.element;
                    break;
                }
                currentNode = currentNode.next;
                counter++;
            }
            return value;
        }
    }

}
