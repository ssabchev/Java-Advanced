import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader =
                new BufferedReader(
                        new InputStreamReader(
                                System.in
                        )
                );


        DoublyLinkedList list = new DoublyLinkedList();

        list.addLast(16);
        list.addLast(23);
        list.addFirst(1);



    }
}

