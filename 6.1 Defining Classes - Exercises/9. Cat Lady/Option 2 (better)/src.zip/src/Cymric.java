public class Cymric extends Cat{
    public Cymric(String name, double furLenght) {
        super(name, furLenght);
    }

    @Override
    public String toString() {
        return String.format("Cymric " + super.toString());
    }

}
