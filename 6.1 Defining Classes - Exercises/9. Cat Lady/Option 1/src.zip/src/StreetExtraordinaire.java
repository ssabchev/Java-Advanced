public class StreetExtraordinaire {
    private String name;
    private int decibelsOfMeows;

    public StreetExtraordinaire(String name, int decibelsOfMeows) {
        this.name = name;
        this.decibelsOfMeows = decibelsOfMeows;
    }

    public String getName() {
        return this.name;
    }

    public int getDecibelsOfMeows() {
        return this.decibelsOfMeows;
    }

}
