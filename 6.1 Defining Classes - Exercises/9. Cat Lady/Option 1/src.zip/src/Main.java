import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;


public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader =
                new BufferedReader(
                        new InputStreamReader(
                                System.in
                        )
                );

        String input;

        HashMap<String, Siamese> siameseCats = new HashMap<>();
        HashMap<String, Cymric> cymricCats = new HashMap<>();
        HashMap<String, StreetExtraordinaire> streetExtraordinaireCats = new HashMap<>();

        while (!"End".equals(input = reader.readLine())) {
            String[] tokens = input.split("\\s+");
            String breed = tokens[0];
            String name = tokens[1];
            int specialData = Integer.parseInt(tokens[2]);

            switch (breed) {
                case "Siamese" :
                    Siamese cat = new Siamese(name, specialData);
                    siameseCats.putIfAbsent(name, cat);
                    break;
                case "Cymric" :
                    Cymric cat1 = new Cymric(name, specialData);
                    cymricCats.putIfAbsent(name, cat1);
                    break;
                case "StreetExtraordinaire" :
                    StreetExtraordinaire cat2 = new StreetExtraordinaire(name, specialData);
                    streetExtraordinaireCats.putIfAbsent(name, cat2);
                    break;
            }
        }

        String catName = reader.readLine();

        if (siameseCats.containsKey(catName)) {
           Siamese cat = siameseCats.get(catName);
            System.out.println(String.format("Siamese %s %.2f",
                    cat.getName(),
                    (double)cat.getEarSize()
                   ));
        } else if (cymricCats.containsKey(catName)){
            Cymric cat1 = cymricCats.get(catName);
            System.out.println(String.format("Cymric %s %.2f",
                    cat1.getName(),
                    (double)cat1.getFurLenght()
            ));
        } else {
            StreetExtraordinaire cat2 = streetExtraordinaireCats.get(catName);
            System.out.println(String.format("StreetExtraordinaire %s %.2f",
                    cat2.getName(),
                    (double)cat2.getDecibelsOfMeows()
            ));
        }


    }
}
