public class Siamese {
    private String name;
    private int earSize;

    public Siamese(String name, int earSize) {
        this.name = name;
        this.earSize = earSize;
    }

    public String getName() {
        return this.name;
    }

    public int getEarSize() {
        return this.earSize;
    }

}
