public class Cymric {
    private String name;
    private int furLenght;

    public Cymric(String name, int furLenght) {
        this.name = name;
        this.furLenght = furLenght;
    }

    public String getName() {
        return this.name;
    }

    public int getFurLenght() {
        return this.furLenght;
    }

}
