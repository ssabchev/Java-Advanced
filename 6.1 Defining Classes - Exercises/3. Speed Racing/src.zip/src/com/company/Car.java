package com.company;

public class Car {
    private String name;
    private double fuel;
    private double fuelCostByKm;
    private double kmTraveled;

    public Car(double fuel, double fuelCostByKm) {
        this.fuel = fuel;
        this.fuelCostByKm = fuelCostByKm;
        this.kmTraveled = 0;
    }

    public double getFuel() {
        return this.fuel;
    }

    public double getFuelCostByKm() {
        return this.fuelCostByKm;
    }

    public double getRange() {
        double range = this.fuel / this.fuelCostByKm;
        return range;
    }

    public void setKmTraveled(double kmTraveled) {
        this.fuel -= kmTraveled * fuelCostByKm;
        this.kmTraveled += kmTraveled;
    }

    public double getKmTraveled() {
        return this.kmTraveled;
    }

}
