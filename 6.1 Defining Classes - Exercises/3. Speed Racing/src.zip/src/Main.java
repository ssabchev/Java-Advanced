import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;


public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader =
                new BufferedReader(
                        new InputStreamReader(
                                System.in
                        )
                );

        int n = Integer.parseInt(reader.readLine());

        LinkedHashMap<String, Car> cars = new LinkedHashMap<>();


        for (int i = 0; i < n; i++) {
            String[] tokens = reader.readLine().split("\\s+");
            String model = tokens[0];
            double fuelAmount = Double.parseDouble(tokens[1]);
            double fuelCostByKm = Double.parseDouble(tokens[2]);

            cars.putIfAbsent(model, new Car(fuelAmount, fuelCostByKm));
        }

        String input;

        while (!"End".equals(input = reader.readLine())) {
            String[] data = input.split("\\s+");
            String model = data[1];
            double kmToGo = Double.parseDouble(data[2]);

            if (cars.get(model).getRange() < kmToGo) {
                System.out.println("Insufficient fuel for the drive");
            } else {
                cars.get(model).setKmTraveled(kmToGo);
            }
        }

        cars.entrySet().stream().forEach(car -> {
            System.out.println(String.format("%s %.2f %.0f",
                    car,
                    car.getKey(),
                    car.getValue()
            )});
    }
}

