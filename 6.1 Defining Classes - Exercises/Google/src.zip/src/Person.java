import java.util.List;

public class Person {
    private String name;
    private  Company company;
    private List<Pokemon> pokemons;

    public Person(String name) {
        this.name = name;
        this.setCompany(new Company());
    }

    public void setCompany (Company company) {
        this.company = company;
    }


}
