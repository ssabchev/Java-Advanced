import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;


public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader =
                new BufferedReader(
                        new InputStreamReader(
                                System.in
                        )
                );

        int n = Integer.parseInt(reader.readLine());

        HashMap<String, Department> departments = new HashMap<>();

        while (n-- > 0) {
            String[] tokens = reader.readLine().split("\\s+");
            String name = tokens[0];
            double salary = Double.parseDouble(tokens[1]);
            String position = tokens[2];
            String departmentName = tokens[3];


            Employee emp = new Employee(name, salary, position);

            if (tokens.length == 5) {
                if (Character.isDigit(tokens[4].charAt(0))) {
                    int age = Integer.parseInt(tokens[4]);
                    emp.setAge(age);
                } else {
                    String email = tokens[4];
                    emp.setEmail(email);
                }
            } else if (tokens.length == 6) {
                String email = tokens[4];
                int age = Integer.parseInt(tokens[5]);
                emp.setEmail(email);
                emp.setAge(age);
            }

            if (!departments.containsKey(departmentName)) {
                departments.put(departmentName, new Department());
                departments.get(departmentName).addEmployee(emp);
            } else {
                departments.get(departmentName).addEmployee(emp);
            }
        }

        Map.Entry<String, Department> highestAvgSalary = departments.entrySet().stream()
                .sorted((f, s) -> {
                    int result = 0;
                    if (s.getValue().getAverageSalary() > f.getValue().getAverageSalary()) {
                        return result = 1;
                    } else if (s.getValue().getAverageSalary() < f.getValue().getAverageSalary()) {
                        return result = -1;
                    } else {
                        return result;
                    }
                }).findFirst()
                .get();

        System.out.println(String.format("Highest Average Salary: %s", highestAvgSalary.getKey()));

        highestAvgSalary.getValue()
                .getEmployees()
                .stream()
                .sorted((f, s) -> Double.compare(s.getSalary(), f.getSalary()))
                .forEach(employee -> {
                    System.out.println(String.format("%s %.2f %s %d",
                            employee.getName(),
                            employee.getSalary(),
                            employee.getEmail(),
                            employee.getAge()
                    ));
                });
    }
}
