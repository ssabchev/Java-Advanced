import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader =
                new BufferedReader(
                        new InputStreamReader(
                                System.in
                        )
                );

        int n = Integer.parseInt(reader.readLine());

        List<Box<Double>> boxes = new ArrayList<>();

        while (n-- > 0) {
            Double number = Double.parseDouble(reader.readLine());

            Box<Double> box = new Box<>(number);
            boxes.add(box);
        }

        Double element = Double.parseDouble(reader.readLine());

        int count = countGreaterElements (boxes, element);

        System.out.println(count);

    }

    private static <T extends Comparable<T>> int countGreaterElements(List<Box<T>> boxes, T element) {
       int count = 0;

        for (Box<T> box : boxes) {
            if (box.getElement().compareTo(element) > 0) {
                count++;
            }
        }
        return count;
    }
}
