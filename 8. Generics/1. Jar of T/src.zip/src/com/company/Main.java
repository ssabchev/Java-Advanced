package com.company;

public class Main {
    public static void main(String[] args) {

        Jar<String> jar = new Jar<>();
        jar.add("tomato");
        System.out.println(jar.remove());



    }
}
